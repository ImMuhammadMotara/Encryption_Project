﻿//Group 10
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace EncryptionProject
{
    public partial class Form1 : Form
    {
        TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
        
        public Form1()
        {
            InitializeComponent();
        }

        public void getKey(string key)
        {
            des.Key = UTF8Encoding.UTF8.GetBytes(key);
            des.Mode = CipherMode.ECB;  //encrypts each block individually 
            des.Padding = PaddingMode.PKCS7; //If the plaintext does not contain the number of bytes to fill the a block length, extra string(padding) is added
        }

        public void Encrypt(string filepath)
        {
            byte[] bytesFromFile = File.ReadAllBytes(filepath);
            byte[] encryptedBytes = des.CreateEncryptor().TransformFinalBlock(bytesFromFile, 0, bytesFromFile.Length);
            File.WriteAllBytes(filepath, encryptedBytes);
        }

        public void decrypt(string filepath)
        {
            byte[] bytesFromFile = File.ReadAllBytes(filepath);
            byte[] decryptedBytes = des.CreateDecryptor().TransformFinalBlock(bytesFromFile, 0, bytesFromFile.Length);
            File.WriteAllBytes(filepath, decryptedBytes);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            encryptBtn.Enabled = false;
            decryptBtn.Enabled = false;
        }

        private void selectBtn_Click(object sender, EventArgs e)
        {
            if (openFileD.ShowDialog() == DialogResult.OK)
            {
                filepathLbl.Text = openFileD.FileName;
                encryptBtn.Enabled = true;
                decryptBtn.Enabled = true;
            }
            else
            {
                MessageBox.Show("No file selected");
            }
        }

        private void encryptBtn_Click(object sender, EventArgs e)
        {
            if (keyTextBox.TextLength == 16)
            {
                try
                {
                    getKey(keyTextBox.Text);
                    Encrypt(filepathLbl.Text);

                    MessageBox.Show("File encrypted");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Enter 16 characters");

                keyTextBox.Focus();
            }
        }

        private void decryptBtn_Click(object sender, EventArgs e)
        {
            try
            {
                getKey(keyTextBox.Text);

                decrypt(filepathLbl.Text);

                MessageBox.Show("File decrypted");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
